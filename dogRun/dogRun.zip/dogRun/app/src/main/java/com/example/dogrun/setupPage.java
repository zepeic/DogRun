package com.example.dogrun;

import static java.lang.Integer.parseInt;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import andriodx.activity;

import androidx.appcompat.app.AppCompatActivity;

public class setupPage extends AppCompatActivity {
    private EditText pin;
    private EditText pin_confirmation;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setup_screen);

    }

    public void Complete(View v) {
        String pin_input = pin.getText().toString();
        String pin_input_confirmation = pin_confirmation.getText().toString();
        int int_pin = parseInt(pin_input);
        int int_pin_confirm = parseInt(pin_input_confirmation);

        if (int_pin == int_pin_confirm) {
            Toast.makeText(getApplicationContext(), "Success!",

                    Toast.LENGTH_LONG).show();

            Intent i = new Intent(getBaseContext(), MainActivity.class);
            i.putExtra("key", int_pin);
            startActivity(i);
        } else if (int_pin != int_pin_confirm) {
            Toast.makeText(getApplicationContext(), "Pins do not match",

                    Toast.LENGTH_LONG).show();
        }
    }

    ActivityResultLauncher<PickVisualMediaRequest> pickMedia =
            registerForActivityResult(new PickVisualMedia(), uri -> {
                // Callback is invoked after the user selects a media item or closes the
                // photo picker.
                if (uri != null) {
                    Log.d("PhotoPicker", "Selected URI: " + uri);
                } else {
                    Log.d("PhotoPicker", "No media selected");
                }
            });


}



