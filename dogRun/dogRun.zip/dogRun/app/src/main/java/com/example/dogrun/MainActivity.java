package com.example.dogrun;

import static java.lang.Integer.parseInt;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private int correct_pin;//Integer.parseInt(getIntent().getStringExtra("key"));
    private EditText pin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        savedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        if(savedPreferences.getBoolean(PREF_SHOW_ABOUT_ON_APP_START, true)){
            Intent intent = new Intent(this, SetupActivity.class);
            startActivity(intent);
            savedPreferences.edit().putBoolean(PREF_SHOW_ABOUT_ON_APP_START, false).commit(); // YOu could do this line within the SetupActivity to ensure they have actually done what you wanted
            finish();


    }

    public void submit(View v) {
        String pin_input = pin.getText().toString();
        int int_pin = parseInt(pin_input);
        if (int_pin == correct_pin) {
            Toast.makeText(getApplicationContext(), "Success!",

                    Toast.LENGTH_LONG).show();
            setContentView(R.layout.option1);
        } else {
            Toast.makeText(getApplicationContext(), "Incorrect Pin",

                    Toast.LENGTH_LONG).show();
        }
    }


    public void phone_mode_click(View v) {

        Toast.makeText(getApplicationContext(), "Phone Mode",

                Toast.LENGTH_LONG).show();
        setContentView(R.layout.phone_mode);

    }
}

